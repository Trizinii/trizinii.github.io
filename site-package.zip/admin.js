
'use strict';
(() => {
const request=async(path,data)=>{const r=await fetch('/api/admin/'+path,{credentials:'same-origin',...(data===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)})});const body=await r.json();if(!r.ok)throw Error(body.error||'Не удалось выполнить действие');return body};
const destination=()=>{let value=new URLSearchParams(location.search).get('next')||'studio.html';if(value==='studio.html'&&/^#[a-z]+$/.test(location.hash))value+=location.hash;return /^studio\.html(?:#[a-z]+)?$/.test(value)?value:'studio.html'};
const form=document.getElementById('adminLoginForm');
if(form){form.addEventListener('submit',async e=>{e.preventDefault();const b=form.querySelector('button'),s=document.getElementById('adminLoginStatus');b.disabled=true;s.textContent='Проверяем данные…';try{await request('login',{username:form.username.value,password:form.password.value});form.password.value='';location.replace(destination())}catch(err){s.textContent=err.message;form.password.focus()}finally{b.disabled=false}});request('me').then(r=>{if(r.admin)location.replace(destination())}).catch(()=>{});}
const logout=document.getElementById('adminLogout');
if(logout){logout.addEventListener('click',async()=>{logout.disabled=true;try{await request('logout',{});location.replace('index.html?login=1&next=studio.html')}catch(e){document.getElementById('adminSessionStatus').textContent=e.message;logout.disabled=false}});request('me').then(r=>{if(!r.admin)location.replace('index.html?login=1&next=studio.html');else document.getElementById('adminSessionStatus').textContent='Администратор: '+r.admin.username+' · сессия 2 часа'}).catch(()=>location.replace('index.html?login=1&next=studio.html'));window.addEventListener('pageshow',()=>request('me').then(r=>{if(!r.admin)location.replace('index.html?login=1&next=studio.html')}).catch(()=>{}));}
})();
