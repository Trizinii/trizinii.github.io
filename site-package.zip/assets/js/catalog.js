window.startCatalog = async function(mode) {
 const grid=document.querySelector('#products'), status=document.querySelector('#status');
 const money=n=>Number(n).toLocaleString('ru-RU')+' ₽';
 const text=(tag,value,cls)=>{const e=document.createElement(tag);e.textContent=value;if(cls)e.className=cls;return e;};
 const load=img=>{if(!img.dataset.src)return;const source=img.parentElement.querySelector('source'); if(source&&source.dataset.srcset){source.srcset=source.dataset.srcset;delete source.dataset.srcset;}img.src=img.dataset.src;delete img.dataset.src;};
 try {
  const res=await fetch('/api/products.php?limit=100&offset=0');if(!res.ok)throw Error('HTTP '+res.status);
  const data=await res.json();if(!data.ok)throw Error('API');
  const observer=('IntersectionObserver' in window)?new IntersectionObserver((entries,obs)=>{for(const e of entries)if(e.isIntersecting){load(e.target);obs.unobserve(e.target);}},{rootMargin:mode==='skeleton'?'200px 0px':'150px 0px',threshold:0.01}):null;
  data.items.forEach((p,i)=>{
   const card=text('article','','card'), box=text('div','','photo'), pic=document.createElement('picture'), source=document.createElement('source'), img=document.createElement('img');
   source.type='image/webp';img.alt=p.alt_text;img.title=p.image_title;img.width=p.width;img.height=p.height;img.decoding='async';
   const eager=i<4, deferred=mode!=='native'&&!eager;
   img.addEventListener('load',()=>{if(img.dataset.src)return;box.classList.add('ready');});
   img.addEventListener('error',()=>{if(img.dataset.fallback){box.classList.add('failed');return;}img.dataset.fallback='1';source.remove();img.src=p.image;});
   if(deferred){source.dataset.srcset=p.image_webp||p.image;img.dataset.src=p.image;}
   else{source.srcset=p.image_webp||p.image;img.loading=eager?'eager':'lazy';if(i===0)img.fetchPriority='high';img.src=p.image;}
   pic.append(source,img);box.append(pic);
   if(mode==='skeleton'&&deferred){const sk=text('div','','skeleton');sk.setAttribute('aria-hidden','true');box.append(sk);}
   if(p.promo_type)box.append(text('span',({day:'Акция дня',week:'Акция недели',month:'Акция месяца'}[p.promo_type]||'Акция')+' −'+p.promo_discount+'%','badge'));
   const body=text('div','','body');body.append(text('h2',p.title),text('p',p.description));const price=text('div',money(p.promo_price||p.price),'price');if(p.promo_price)price.append(text('span',money(p.old_price),'old'));body.append(price);
   if(p.reviews_count)body.append(text('div','★ '+p.avg_rating+' · отзывов: '+p.reviews_count,'rating'));
   const actions=text('div','','catalog-actions');const buy=text('a','Выбрать размер','catalog-action');buy.href='/index.html?product='+p.id;const reviews=text('a','Отзывы','catalog-action secondary');reviews.href='/reviews.html?product_id='+p.id;actions.append(buy,reviews);body.append(actions);card.append(box,body);grid.append(card);
   if(deferred){if(observer)observer.observe(img);else load(img);}
  });
  status.textContent='В каталоге '+data.total+' товаров';
 } catch(e){status.textContent='Не удалось загрузить каталог. Обновите страницу.';status.classList.add('error');}
 finally{grid.setAttribute('aria-busy','false');}
};