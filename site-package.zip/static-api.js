'use strict';
const STATIC_CATALOG={"new": [{"id": 1, "name": "Кожаная куртка премиум", "price": 34990, "category": "new", "image": "assets/photo-08-736.webp", "description": "Премиальная кожаная куртка ручной работы", "badge": "new", "sizes": ["XS", "S", "M", "L", "XL"]}, {"id": 2, "name": "Свитер", "price": 18990, "category": "new", "image": "assets/photo-10-800.webp", "description": "Кашемировый свитер из 100% кашемира", "badge": "new", "sizes": ["S", "M", "L", "XL"]}, {"id": 3, "name": "Платье", "price": 22990, "category": "new", "image": "assets/photo-02-1200.webp", "description": "Шелковое платье с авторским принтом", "badge": "new", "sizes": ["XS", "S", "M", "L"]}, {"id": 4, "name": "Кожаные кроссовки", "price": 14990, "category": "new", "image": "assets/photo-15-968.webp", "description": "Кожаные кроссовки премиум класса", "badge": "new", "sizes": ["38", "39", "40", "41", "42", "43"]}], "men": [{"id": 5, "name": "Пиджак", "price": 45990, "category": "men", "image": "assets/photo-05-571.webp", "description": "Классический костюм тройка из итальянской шерсти", "sizes": ["46", "48", "50", "52", "54"]}, {"id": 6, "name": "Кожаные ботинки", "price": 28990, "category": "men", "image": "assets/photo-03-1080.webp", "description": "Кожаные ботинки Goodyear Welted", "sizes": ["40", "41", "42", "43", "44", "45"]}, {"id": 7, "name": "Пальто", "price": 38990, "category": "men", "image": "assets/photo-01-1080.webp", "description": "Шерстяное пальто двойного переплетения", "sizes": ["S", "M", "L", "XL", "XXL"]}, {"id": 8, "name": "Рубашка", "price": 12990, "category": "men", "image": "assets/photo-12-328.webp", "description": "Рубашка из 200s египетского хлопка", "sizes": ["S", "M", "L", "XL"]}], "women": [{"id": 9, "name": "Платье", "price": 32990, "category": "women", "image": "assets/photo-07-600.webp", "description": "Вечернее платье с ручной вышивкой", "sizes": ["XS", "S", "M", "L"]}, {"id": 10, "name": "Кардиган", "price": 21990, "category": "women", "image": "assets/photo-00-1200.webp", "description": "Кашемировый кардиган oversize", "sizes": ["XS", "S", "M", "L", "XL"]}, {"id": 11, "name": "Кожаная юбка", "price": 18990, "category": "women", "image": "assets/photo-16-1093.webp", "description": "Кожаная юбка миди длины", "sizes": ["XS", "S", "M", "L"]}, {"id": 12, "name": "Блузка", "price": 16990, "category": "women", "image": "assets/photo-20-720.webp", "description": "Шелковый блузон с авторским принтом", "sizes": ["XS", "S", "M", "L"]}], "sale": [{"id": 13, "name": "Кожаная куртка", "price": 24990, "oldPrice": 34990, "category": "sale", "image": "assets/photo-17-1200.webp", "description": "Кожаная куртка премиум класса", "badge": "sale", "sizes": ["XS", "S", "M", "L", "XL"]}, {"id": 14, "name": "Джинсы", "price": 11990, "oldPrice": 18990, "category": "sale", "image": "assets/photo-06-736.webp", "description": "Джинсы из японского сырого денима", "badge": "sale", "sizes": ["28", "30", "32", "34", "36"]}, {"id": 15, "name": "Шерстяной свитер", "price": 13990, "oldPrice": 21990, "category": "sale", "image": "assets/photo-11-960.webp", "description": "Шерстяной свитер из мериносовой шерсти", "badge": "sale", "sizes": ["S", "M", "L", "XL"]}, {"id": 16, "name": "Кожаные лоферы", "price": 17990, "oldPrice": 26990, "category": "sale", "image": "assets/photo-14-962.webp", "description": "Кожаные лоферы ручной сборки", "badge": "sale", "sizes": ["39", "40", "41", "42", "43"]}]};
const ADMIN_DEMO_HASH="d625fddbfef16f6608fe7cca90c0e3e8de4f141989f74248708bc6a396687893";
'use strict';
// GitHub Pages teaching edition: all mutable data belongs to this browser.
(()=>{
 const nativeFetch=window.fetch.bind(window),KEY='trizinii-pages-v1',SESSION='trizinii-pages-session';
 const initial=()=>({users:[],subscribers:[],orders:[],events:[],mail:[],queue:[],feedback:[],promotions:[]});
 const read=()=>{try{return {...initial(),...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch{return initial()}};
 const save=s=>localStorage.setItem(KEY,JSON.stringify(s));
 const now=()=>Date.now()/1000,id=xs=>Math.max(0,...xs.map(x=>x.id||0))+1;
 const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const session=()=>{try{return JSON.parse(sessionStorage.getItem(SESSION)||'{}')}catch{return {}}};
 const reply=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json;charset=utf-8'}});
 const fail=(message,status=400)=>{throw {message,status}};
 const hash=async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)))).map(x=>x.toString(16).padStart(2,'0')).join('');
 const passwordHash=async(password,salt)=>{const k=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);return Array.from(new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:new TextEncoder().encode(salt),iterations:160000},k,256))).map(x=>x.toString(16).padStart(2,'0')).join('')};
 const mailTitles={confirm:'Подтвердите подписку на TRIZINII',welcome:'Добро пожаловать в TRIZINII',size_guide:'Как выбрать размер',capsule:'Капсула на неделю',reactivation:'Какие темы вам интересны?',order:'Учебный заказ подтверждён',feedback:'Как прошла покупка?',cancelled:'Учебный заказ отменён'};
 function schedule(s,email,template,key,sendAt=now(),subscriber=null,payload={}){if(!s.queue.some(x=>x.key===key))s.queue.push({id:id(s.queue),recipient:email,template,key,send_at:sendAt,subscriber_id:subscriber,status:'pending',payload})}
 function cancel(s,sid){s.queue.forEach(q=>{if(q.subscriber_id===sid&&q.status==='pending'&&['welcome','size_guide','capsule','reactivation'].includes(q.template))q.status='cancelled'})}
 function process(s){let count=0;for(const q of s.queue.filter(q=>q.status==='pending'&&q.send_at<=now())){
  const sub=s.subscribers.find(x=>x.id===q.subscriber_id);if((['welcome','size_guide','capsule','reactivation'].includes(q.template)&&sub?.status!=='confirmed')||(q.template==='confirm'&&sub?.status!=='pending')){q.status='cancelled';continue}
  const token=encodeURIComponent(sub?.token||''),subject=mailTitles[q.template],origin=location.origin;
  let text='Полезные материалы TRIZINII о выборе размера, сочетании вещей и уходе.',links=[['Читать журнал',origin+'/blog/index.html']];
  if(q.template==='confirm'){text='Подтвердите учебную подписку. Письмо доступно только в браузере, отправки на email нет.';links=[['Подтвердить подписку',origin+'/confirm.html?token='+token]]}
  if(['order','cancelled','feedback'].includes(q.template)){text=`Учебный заказ №${q.payload.order_id}. Сумма ${q.payload.total} ₽. Оплата не списывается.`;links=[['Открыть магазин',origin+'/index.html'],['Оценить покупку',origin+'/feedback.html?order='+q.payload.order_id]]}
  if(sub&&q.template!=='confirm')links.push(['Настроить темы или отписаться',origin+'/preferences.html?token='+token]);
  const plain=subject+'\n\n'+text+'\n\n'+links.map(([label,url])=>label+': '+url).join('\n');
  const html=`<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(subject)}</title><body style="font-family:Arial,sans-serif;margin:0;background:#f4f0fa;color:#211b30"><main style="max-width:600px;margin:30px auto;padding:28px;background:white"><h1>TRIZINII</h1><h2>${esc(subject)}</h2><p style="line-height:1.6">${esc(text)}</p>${links.map(([label,url])=>`<p><a href="${esc(url)}">${esc(label)}</a></p>`).join('')}<p>Учебное письмо. Интернет-отправка отключена.</p></main></body></html>`;
  s.mail.push({id:id(s.mail),queue_id:q.id,recipient:q.recipient,subject,plain,html,created_at:now()});q.status='saved_local';count++;
 }return count}
 function admin(){if(session().role!=='admin'||session().expires<now())fail('Войдите как администратор',401)}
 const publicUser=u=>u?({id:u.id,name:u.name,email:u.email}):null;
 const emailValid=e=>/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(e)&&e.length<=254;
 window.fetch=async(input,options={})=>{
  const url=new URL(typeof input==='string'?input:input.url,location.href);
  if(url.origin!==location.origin||!url.pathname.startsWith('/api/'))return nativeFetch(input,options);
  try{
   const s=read(),method=(options.method||'GET').toUpperCase(),data=JSON.parse(options.body||'{}'),path=url.pathname.slice(5),sess=session(),user=s.users.find(x=>x.id===sess.userId&&sess.expires>now());
   const done=(body,status=200)=>{save(s);return reply(body,status)};
   if(method==='GET'){
    if(path==='me')return done({user:publicUser(user)});
    if(path==='admin/me')return done({admin:sess.role==='admin'&&sess.expires>now()?{username:'admin'}:null});
    if(path==='promotions')return done({promotions:s.promotions.filter(x=>x.active&&(!x.start||x.start<=new Date().toISOString().slice(0,10))&&(!x.end||x.end>=new Date().toISOString().slice(0,10)))});
    if(path==='orders'){if(!user)fail('Войдите в аккаунт',401);return done({orders:s.orders.filter(x=>x.user_id===user.id)})}
    if(path==='confirm'){
     const sub=s.subscribers.find(x=>x.token===url.searchParams.get('token'));if(!sub)fail('Ссылка не найдена',404);if(sub.status==='unsubscribed')fail('Подписка отменена',409);
     if(sub.status==='pending'){sub.status='confirmed';sub.confirmed_at=now();for(const [name,days] of [['welcome',0],['size_guide',7],['capsule',14],['reactivation',30]]){if(sub.frequency==='monthly'&&['size_guide','capsule'].includes(name))continue;schedule(s,sub.email,name,sub.token+':'+name,now()+days*86400,sub.id)}}process(s);return done({ok:true,message:'Подписка подтверждена. Спасибо!'})
    }
    if(path==='preferences'){const sub=s.subscribers.find(x=>x.token===url.searchParams.get('token'));if(!sub)fail('Нужна персональная ссылка из письма',404);return done({interest:sub.interest,frequency:sub.frequency,status:sub.status})}
    if(path==='studio'){admin();process(s);return done({contacts:s.subscribers,feedback:s.feedback,subscribers:s.subscribers,events:s.events.slice(-300).reverse(),mail:s.mail.slice().reverse(),queue:s.queue.slice().reverse(),promotions:s.promotions})}
    if(path.startsWith('mail/')){admin();const match=path.match(/^mail\/(\d+)\.(html|txt|eml)$/),m=s.mail.find(x=>x.id===Number(match?.[1]));if(!m)fail('Письмо не найдено',404);return new Response(match[2]==='html'?m.html:match[2]==='txt'?m.plain:'Subject: '+m.subject+'\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n'+m.plain,{headers:{'Content-Type':match[2]==='html'?'text/html;charset=utf-8':'text/plain;charset=utf-8'}})}
   }
   if(method==='POST'){
    if(path==='admin/logout'){sessionStorage.removeItem(SESSION);return done({ok:true})}
    if(path==='admin/login'||path==='login'||path==='register'){
     const email=String(data.email||data.username||'').trim().toLowerCase(),password=String(data.password||'');
     if(path!=='register'&&(email==='admin'||path==='admin/login')){
      if(email!=='admin'||await hash(password)!==ADMIN_DEMO_HASH)fail('Неверный логин или пароль администратора',401);
      sessionStorage.setItem(SESSION,JSON.stringify({role:'admin',expires:now()+7200}));return done({ok:true,admin:{username:'admin'}})
     }
     if(!emailValid(email)||password.length<8||password.length>128)fail('Введите email и пароль от 8 до 128 символов');
     let account=s.users.find(x=>x.email===email);
     if(path==='register'){if(account)fail('Email уже зарегистрирован',409);const name=String(data.name||'').trim().slice(0,80);if(!name)fail('Укажите имя');const salt=crypto.randomUUID();account={id:id(s.users),email,name,salt,password_hash:await passwordHash(password,salt)};s.users.push(account)}
     if(!account||account.password_hash!==await passwordHash(password,account.salt))fail('Неверный email или пароль',401);
     sessionStorage.setItem(SESSION,JSON.stringify({role:'buyer',userId:account.id,expires:now()+86400}));return done({user:publicUser(account)})
    }
    if(path==='logout'){sessionStorage.removeItem(SESSION);return done({ok:true})}
    if(path==='event'){const allowed=['page_view','catalog_view','size_guide_open','add_to_cart','purchase','social_share','content_view','content_download','content_catalog_click','scroll_50','scroll_90','landing_view','landing_cta','notification_opt_in','content_read','ui_interaction'];if(!allowed.includes(data.name))fail('Неизвестное событие');s.events.push({id:id(s.events),name:data.name,details:data.details||{},created_at:now()});s.events=s.events.slice(-1000);return done({ok:true})}
    if(path==='subscribe'){
     const email=String(data.email||'').trim().toLowerCase();if(!emailValid(email)||!data.consent||!['all','men','women','care'].includes(data.interest)||!['weekly','monthly'].includes(data.frequency))fail('Укажите email, темы и согласие');
     let sub=s.subscribers.find(x=>x.email===email);if(!sub){sub={id:id(s.subscribers),email};s.subscribers.push(sub)}
     if(!sub.status||sub.status==='unsubscribed'){Object.assign(sub,{token:crypto.randomUUID(),status:'pending',interest:data.interest,frequency:data.frequency,consent_at:now(),confirmed_at:null});schedule(s,email,'confirm',sub.token+':confirm',now(),sub.id);process(s)}
     return done({ok:true,message:'Учебное письмо создано в этом браузере. Откройте панель администратора → Почтовый ящик. На email письмо не отправляется.'})
    }
    if(path==='preferences'||path==='unsubscribe'){
     const sub=s.subscribers.find(x=>x.token===data.token);if(!sub)fail('Ссылка не найдена',404);
     if(path==='unsubscribe'){sub.status='unsubscribed';cancel(s,sub.id)}else{if(!['all','men','women','care'].includes(data.interest)||!['weekly','monthly'].includes(data.frequency))fail('Недопустимые предпочтения');Object.assign(sub,{interest:data.interest,frequency:data.frequency});if(sub.frequency==='monthly')s.queue.forEach(q=>{if(q.subscriber_id===sub.id&&q.status==='pending'&&['size_guide','capsule'].includes(q.template))q.status='cancelled'})}return done({ok:true})
    }
    if(path==='process'){admin();return done({ok:true,processed:process(s)})}
    if(path==='admin/promotion'){
     admin();if(data.action==='remove'){s.promotions=s.promotions.filter(x=>x.id!==Number(data.id));return done({ok:true})}
     if(data.action==='toggle'){const p=s.promotions.find(x=>x.id===Number(data.id));if(p)p.active=!p.active;return done({ok:true})}
     const title=String(data.title||'').trim().slice(0,100),description=String(data.description||'').trim().slice(0,600),start=String(data.start||''),end=String(data.end||'');
     if(!title||!description)fail('Заполните название и описание');if(start&&end&&end<start)fail('Дата окончания должна быть не раньше начала');
     const image=String(data.image||'').trim();if(image&&!/^https:\/\//.test(image))fail('Изображение должно иметь ссылку https://');
     s.promotions.push({id:id(s.promotions),title,description,benefit:String(data.benefit||'').slice(0,120),kind:['day','week','month'].includes(data.kind)?data.kind:'week',start,end,image,active:true});return done({ok:true})
    }
    if(path==='orders'){
     if(!user)fail('Войдите в аккаунт',401);const duplicate=s.orders.find(x=>x.request_key===data.request_key&&x.user_id===user.id);if(duplicate)return done({ok:true,id:duplicate.id,total:duplicate.total});
     if(!data.request_key||!Array.isArray(data.items)||!data.items.length||data.items.length>50)fail('Проверьте корзину');
     const catalog=Object.values(STATIC_CATALOG).flat(),clean=[];let total=0;
     for(const item of data.items){const p=catalog.find(x=>x.id===Number(item.id));if(!p||!Number.isInteger(item.quantity)||item.quantity<1||item.quantity>20||(p.sizes?.length&&!p.sizes.includes(item.size)))fail('Проверьте товары, размеры и количество');clean.push({...item,price:p.price,name:p.name});total+=p.price*item.quantity}
     const shipping=total>=10000?0:total>=5000?300:500;total+=shipping;const order={id:id(s.orders),user_id:user.id,items:clean,total,status:'confirmed',created_at:now(),request_key:data.request_key};s.orders.unshift(order);const sub=s.subscribers.find(x=>x.email===user.email);if(sub)cancel(s,sub.id);const payload={order_id:order.id,total};schedule(s,user.email,'order','order:'+order.id,now(),null,payload);schedule(s,user.email,'feedback','feedback:'+order.id,now()+7*86400,null,payload);process(s);return done({ok:true,id:order.id,total,shipping})
    }
    if(path==='cancel-order'){const order=s.orders.find(x=>x.id===Number(data.id)&&x.user_id===user?.id);if(!order)fail('Заказ не найден',404);if(order.status!=='cancelled'){order.status='cancelled';s.queue.forEach(q=>{if(q.key==='feedback:'+order.id&&q.status==='pending')q.status='cancelled'});schedule(s,user.email,'cancelled','cancelled:'+order.id,now(),null,{order_id:order.id,total:order.total});process(s)}return done({ok:true})}
    if(path==='feedback'){if(!user)fail('Войдите в аккаунт покупателя',401);const order=s.orders.find(x=>x.id===Number(data.order_id)&&x.user_id===user.id);if(!order)fail('Можно оценить только свой заказ',404);if(order.status==='cancelled')fail('Заказ отменён',409);if(!Number.isInteger(data.score)||data.score<0||data.score>10)fail('Выберите оценку от 0 до 10');const row=s.feedback.find(x=>x.order_id===order.id)||{};Object.assign(row,{order_id:order.id,user_id:user.id,score:data.score,comment:String(data.comment||'').slice(0,1000),created_at:now()});if(!s.feedback.includes(row))s.feedback.push(row);return done({ok:true,message:'Спасибо! Оценка сохранена в этом браузере.'})}
   }
   fail('Маршрут не найден',404);
  }catch(e){return reply({error:e.message||'Не удалось сохранить данные браузера'},e.status||400)}
 };
 document.addEventListener('click',async e=>{
  const a=e.target.closest('a[href]');if(!a)return;const u=new URL(a.href,location.href);if(u.origin!==location.origin||!/^\/api\/mail\/\d+\.(html|txt|eml)$/.test(u.pathname))return;e.preventDefault();
  let win;if(!u.pathname.endsWith('.eml'))win=window.open('about:blank','_blank');const r=await fetch(u.href);if(!r.ok){if(win)win.close();return}const b=await r.blob(),target=URL.createObjectURL(b);if(win)win.location=target;else{const link=document.createElement('a');link.href=target;link.download='TRIZINII-'+u.pathname.split('/').at(-1);link.click()}setTimeout(()=>URL.revokeObjectURL(target),60000)
 });
 document.addEventListener('DOMContentLoaded',()=>{
  const main=document.querySelector('main');if(main){const note=document.createElement('p');note.className='browser-edition-note';note.textContent='Учебная версия. Заказы, подписки и изменения сохраняются в этом браузере.';main.prepend(note)}
  if(document.getElementById('adminLogout')&&(session().role!=='admin'||session().expires<now())){location.replace('index.html?login=1&next=studio.html');return}
 });
})();
