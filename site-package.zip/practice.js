'use strict';
const api=async(path,data)=>{const r=await fetch('/api/'+path,{credentials:'same-origin',...(data===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)})});const j=await r.json();if(!r.ok){if(r.status===401&&document.getElementById('adminLogout'))location.replace('admin.html?next='+encodeURIComponent('studio.html'+location.hash));throw Error(j.error||'Не удалось выполнить действие')}return j;};
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const device=()=>matchMedia('(max-width:600px)').matches?'mobile':matchMedia('(max-width:1000px)').matches?'tablet':'desktop';
const utm={};for(const k of ['utm_source','utm_medium','utm_campaign','utm_content','utm_term']){const v=new URLSearchParams(location.search).get(k);if(v)utm[k]=v.slice(0,150)}
if(Object.keys(utm).length)sessionStorage.setItem('trizinii-utm',JSON.stringify(utm));else Object.assign(utm,JSON.parse(sessionStorage.getItem('trizinii-utm')||'{}'));
window.triziniiTrack=(name,details={})=>api('event',{name,details:{...utm,page:location.pathname,device:device(),...details}}).catch(()=>{});
window.triziniiGoal=(name)=>({cart_open:'catalog_view',review_form_open:'catalog_view'}[name]&&triziniiTrack('catalog_view'));
triziniiTrack(location.pathname.includes('/blog/')?'content_view':'page_view');
const toast=(text)=>{if(typeof showNotification==='function')showNotification(text);};

if(document.getElementById('authModal')){
 checkAuth=async()=>{try{const r=await api('me');currentUser=r.user;if(currentUser)showUserInfo();else hideUserInfo()}catch(e){toast('Запустите сайт через файл «Запустить сайт.cmd»')}};
 loginUser=async(email,password)=>{const button=document.querySelector('#loginForm button[type=submit]');button.disabled=true;try{const result=await api('login',{email:email.trim(),password});document.getElementById('password').value='';if(result.admin){const destination=new URLSearchParams(location.search).get('next');location.assign(/^studio\.html(?:#[a-z]+)?$/.test(destination||'')?destination:'studio.html');return}currentUser=result.user;showUserInfo();authModal.classList.remove('active');showNotification('Вы вошли в аккаунт','success')}catch(e){showNotification(e.message,'error')}finally{button.disabled=false}};
 registerUser=async(name,email,password)=>{try{currentUser=(await api('register',{name,email,password})).user;showUserInfo();authModal.classList.remove('active');showNotification('Регистрация завершена','success')}catch(e){showNotification(e.message,'error')}};
 logoutUser=async()=>{await api('logout',{});currentUser=null;hideUserInfo();showNotification('Вы вышли из аккаунта')};
 let orderPending=false,orderKey=null;
 checkout=async()=>{
  if(orderPending)return;if(!cart.length)return showNotification('Добавьте товары в корзину');
  if(!currentUser){showNotification('Войдите, чтобы оформить учебный заказ');authModal.classList.add('active');return}
  orderPending=true;checkoutBtn.disabled=true;orderKey=orderKey||crypto.randomUUID();
  try{const r=await api('orders',{items:cart.map(({id,size,quantity})=>({id,size,quantity})),request_key:orderKey,device:device()});cart=[];saveCart();updateCartUI();cartModal.classList.remove('active');orderKey=null;showNotification(`Учебный заказ №${r.id} оформлен. ${formatPrice(r.total)} ₽. Оплата не списывается.`,'success');if(Notification.permission==='granted')new Notification('TRIZINII',{body:`Учебный заказ №${r.id} подтверждён`})}catch(e){showNotification(e.message,'error')}finally{orderPending=false;checkoutBtn.disabled=false}
 };
 const oldAdd=addToCart;addToCart=(p,size)=>{oldAdd(p,size);triziniiTrack('add_to_cart',{product:p.id})};
}

const campaigns=[{platform:'Яндекс.Директ',name:'TRIZINII Поиск',budget:12000,target:'Одежда и размер',audience:'Покупатели одежды; коммерческие запросы; исключить информационные и нецелевые запросы'},{platform:'Google Ads',name:'TRIZINII Search',budget:0,target:'Резервный проект',audience:'Шаблон поисковой кампании для доступных регионов; запуск после проверки аккаунта'},{platform:'VK Реклама',name:'TRIZINII Гардероб',budget:8000,target:'Интересы и ретаргетинг',audience:'18-35 лет; стиль и одежда; ретаргетинг только после согласия и подключения пикселя'}];
const model=[{name:'A Размер',impressions:20000,clicks:200,spend:4000,orders:8,revenue:48000},{name:'B Стиль',impressions:18000,clicks:108,spend:3240,orders:3,revenue:18000},{name:'C Капсула',impressions:16000,clicks:240,spend:4800,orders:12,revenue:72000}];
const days=['Гид по размеру','Опрос о гардеробе','Видео о мерках','Новинки','Ответ стилиста','Капсула на неделю','История вещи','Уход за свитером','Вопрос подписчика','Видео сочетаний','Подборка образов','Отзывы и UGC','Памятка по размеру','Итоги и опрос'];
const workflow=[['Подтверждение адреса','Сразу после добровольной подписки. До подтверждения нет рекламных писем.'],['Welcome','После подтверждения. Гид по размерам и полезный первый шаг.'],['Onboarding','Через 7 дней: памятка по выбору размера.'],['Nurture','Через 14 дней: капсула из восьми вещей.'],['Реактивация','Через 30 дней: настройка интересов.'],['Сервисные письма','Подтверждение заказа сразу; обратная связь через 7 дней. Отмена заказа отменяет запрос отзыва.']];
function download(name,body,type){const u=URL.createObjectURL(new Blob([body],{type}));const a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)}
let studioData=null;
async function refreshStudio(){
 try{studioData=await api('studio');const d=studioData;
 renderExtraStudio(d);
 const list=document.getElementById('mailList');if(list)list.innerHTML=d.mail.map(m=>`<article class="mail-card"><h3>${esc(m.subject)}</h3><p>${esc(m.recipient)} · ${new Date(m.created_at*1000).toLocaleString('ru-RU')}</p><a href="/api/mail/${m.id}.html" target="_blank" rel="noopener">Открыть письмо</a><a href="/api/mail/${m.id}.txt" target="_blank" rel="noopener">Текст</a><a href="/api/mail/${m.id}.eml" download>Скачать EML</a></article>`).join('')||'<p class="no-data">Пока нет писем. Подпишитесь на главной странице.</p>';
 const queue=document.getElementById('queueTable');if(queue)queue.innerHTML=table(['ID','Шаблон','Когда','Статус'],d.queue.map(q=>[q.id,q.template,new Date(q.send_at*1000).toLocaleString('ru-RU'),q.status]));
 const summary=document.getElementById('eventSummary');if(summary){const counts={};for(const e of d.events)counts[e.name]=(counts[e.name]||0)+1;summary.innerHTML=Object.entries(counts).map(([k,v])=>`<div><h3>${esc(k)}</h3><strong>${v}</strong></div>`).join('')||'<p>События появятся после просмотра магазина.</p>'}
 const events=document.getElementById('eventTable');if(events)events.innerHTML=table(['Событие','Устройство','Источник','Время'],d.events.slice(0,30).map(e=>[e.name,e.details.device||'',e.details.utm_source||'',new Date(e.created_at*1000).toLocaleTimeString('ru-RU')]));
 }catch(e){const el=document.getElementById('mailStatus');if(el)el.textContent=e.message}
}
function table(headers,rows){return `<table><thead><tr>${headers.map(h=>`<th scope="col">${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>'<tr>'+r.map((v,i)=>`<td data-label="${esc(headers[i])}">${esc(v)}</td>`).join('')+'</tr>').join('')}</tbody></table>`}

document.addEventListener('DOMContentLoaded',()=>{
 if(document.getElementById('authModal')){
  const params=new URLSearchParams(location.search);
  if(params.get('login')==='1'){document.getElementById('authModal').classList.add('active');document.getElementById('email').focus()}
  api('admin/me').then(r=>{if(!r.admin)return;const link=document.createElement('a');link.className='btn btn-outline btn-auth';link.href='studio.html';link.id='adminCabinetLink';link.textContent='Панель администратора';document.querySelector('.header-controls').prepend(link)}).catch(()=>{});
 }

 const mainNav=document.querySelector('.main-nav');if(mainNav){mainNav.id='mainNavigation';const menu=document.querySelector('.mobile-menu')||document.createElement('button');menu.type='button';menu.className='btn btn-outline mobile-menu';menu.textContent='Меню';menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-controls','mainNavigation');if(!menu.isConnected)document.querySelector('.header-controls').append(menu);menu.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));mainNav.classList.toggle('expanded',open)});mainNav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{menu.setAttribute('aria-expanded','false');mainNav.classList.remove('expanded')}))}
 const sf=document.getElementById('subscribeForm');sf?.addEventListener('submit',async e=>{e.preventDefault();const status=document.getElementById('subscribeStatus'),btn=sf.querySelector('button[type=submit]');btn.disabled=true;try{const r=await api('subscribe',{email:sf.email.value,interest:sf.interest.value,frequency:sf.frequency.value,consent:document.getElementById('subscriberConsent').checked});status.textContent=r.message}catch(err){status.textContent=err.message}finally{btn.disabled=false}});
 const token=new URLSearchParams(location.search).get('token');
 const confirm=document.getElementById('confirmStatus');if(confirm)api('confirm?token='+encodeURIComponent(token||'')).then(r=>confirm.textContent=r.message).catch(e=>confirm.textContent=e.message);
 const pf=document.getElementById('preferencesForm'),ps=document.getElementById('preferenceStatus');
 if(pf&&token)api('preferences?token='+encodeURIComponent(token)).then(r=>{pf.hidden=false;document.getElementById('preferenceInterest').value=r.interest;document.getElementById('preferenceFrequency').value=r.frequency;ps.textContent=r.status==='unsubscribed'?'Вы отписаны. Рекламные письма отменены.':'Выберите темы и удобную частоту.'}).catch(e=>ps.textContent=e.message);
 pf?.addEventListener('submit',async e=>{e.preventDefault();try{await api('preferences',{token,interest:document.getElementById('preferenceInterest').value,frequency:document.getElementById('preferenceFrequency').value});ps.textContent='Предпочтения сохранены.'}catch(err){ps.textContent=err.message}});
 document.getElementById('unsubscribe')?.addEventListener('click',async()=>{try{await api('unsubscribe',{token});ps.textContent='Вы отписаны. Запланированные рекламные письма отменены.';pf.hidden=true}catch(e){ps.textContent=e.message}});
 const calendar=document.getElementById('communityCalendar');if(calendar)calendar.innerHTML=days.map((s,i)=>`<div class="calendar-day"><b>День ${i+1}</b><p>${esc(s)}</p><span>${i%2?'Telegram':'ВКонтакте'}</span></div>`).join('');
 document.querySelectorAll('.share-button').forEach(b=>b.addEventListener('click',async()=>{const url=new URL(b.dataset.href,location.href).href;try{if(navigator.share)await navigator.share({title:'TRIZINII',url});else await navigator.clipboard.writeText(url);document.getElementById('shareStatus').textContent='Ссылка готова для публикации.';triziniiTrack('social_share')}catch(e){document.getElementById('shareStatus').textContent='Ссылка: '+url}}));
 const lc=document.getElementById('landingCTA');if(lc){let v=new URLSearchParams(location.search).get('variant');if(!['a','b'].includes(v)){v=sessionStorage.getItem('trizinii-ab')||(['a','b'][Math.floor(Math.random()*2)]);sessionStorage.setItem('trizinii-ab',v)}if(v==='b'){document.getElementById('landingHeadline').textContent='Найдите свою капсулу на неделю';lc.textContent='Выбрать вещи для капсулы'}triziniiTrack('landing_view',{variant:v});lc.addEventListener('click',()=>triziniiTrack('landing_cta',{variant:v}))}
 const cc=document.getElementById('campaignCards');if(cc){const saved=JSON.parse(localStorage.getItem('trizinii-campaigns')||'{}');cc.innerHTML=campaigns.map((c,i)=>`<article class="campaign-card"><p class="eyebrow">${esc(c.platform)}</p><h3>${esc(c.name)}</h3><p>${esc(c.audience)}</p><p>Бюджет на 30 дней: <strong>${c.budget.toLocaleString('ru-RU')} ₽</strong></p><label for="campaign${i}">Статус плана</label><select id="campaign${i}" data-campaign="${i}"><option value="draft">Черновик</option><option value="ready">Готов к проверке</option><option value="paused">Пауза</option></select><a href="landing.html?utm_source=${i===0?'yandex':i===1?'google':'vk'}&utm_medium=${i===2?'paid_social':'cpc'}&utm_campaign=wardrobe&variant=a">Проверить посадочную страницу</a></article>`).join('');cc.querySelectorAll('select').forEach(s=>{s.value=saved[s.dataset.campaign]||'draft';s.addEventListener('change',()=>{saved[s.dataset.campaign]=s.value;localStorage.setItem('trizinii-campaigns',JSON.stringify(saved))})});document.querySelector('#adMetrics tbody').innerHTML=model.map(m=>`<tr>${[m.name,m.impressions,m.clicks,m.spend,m.orders,(m.clicks/m.impressions*100).toFixed(2)+'%',(m.spend/m.clicks).toFixed(2),(m.spend/m.orders).toFixed(2),(m.revenue/m.spend).toFixed(2)].map(x=>`<td>${esc(x)}</td>`).join('')}</tr>`).join('');document.getElementById('emailWorkflow').innerHTML=workflow.map(([h,p])=>`<article><h3>${h}</h3><p>${p}</p></article>`).join('');refreshStudio()}
 document.querySelectorAll('[data-panel]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-panel]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));document.querySelectorAll('.studio-panel').forEach(p=>p.hidden=p.id!==b.dataset.panel);refreshStudio()}));
 document.getElementById('processQueue')?.addEventListener('click',async()=>{try{const r=await api('process',{});document.getElementById('mailStatus').textContent=`Сформировано новых писем: ${r.processed}`;refreshStudio()}catch(e){document.getElementById('mailStatus').textContent=e.message}});
 document.getElementById('exportEvents')?.addEventListener('click',()=>download('trizinii-events.json',JSON.stringify(studioData?.events||[],null,2),'application/json'));
 document.getElementById('exportAds')?.addEventListener('click',()=>download('trizinii-campaigns.csv','\ufeffПлатформа;Кампания;Бюджет;Статус\n'+campaigns.map((c,i)=>`${c.platform};${c.name};${c.budget};${document.getElementById('campaign'+i).value}`).join('\n'),'text/csv;charset=utf-8'));
 if(document.getElementById('authModal')){
  const orders=document.createElement('button');orders.className='btn btn-outline btn-auth';orders.textContent='Мои заказы';orders.id='myOrders';document.getElementById('userInfo').append(orders);
  const dialog=document.createElement('dialog');dialog.className='account-orders';dialog.setAttribute('aria-label','Мои учебные заказы');dialog.innerHTML='<h2>Мои учебные заказы</h2><p>Заказы созданы в учебном магазине. Оплата не списывается.</p><div id="ordersList"></div><button id="enableNotifications">Включить уведомления</button><button id="closeOrders">Закрыть</button><p id="ordersStatus" role="status"></p>';document.body.append(dialog);
  const refreshOrders=async()=>{const r=await api('orders');document.getElementById('ordersList').innerHTML='<ul>'+r.orders.map(o=>`<li>№${o.id} · ${o.total.toLocaleString('ru-RU')} ₽ · ${o.status==='cancelled'?'отменён':'подтверждён'}${o.status!=='cancelled'?` <a href="feedback.html?order=${o.id}">Оценить покупку</a> <button data-cancel="${o.id}">Отменить заказ №${o.id}</button>`:''}</li>`).join('')+'</ul>';dialog.querySelectorAll('[data-cancel]').forEach(b=>b.addEventListener('click',async()=>{await api('cancel-order',{id:Number(b.dataset.cancel)});refreshOrders()}))};
  orders.addEventListener('click',async()=>{await refreshOrders();dialog.showModal()});document.getElementById('closeOrders').onclick=()=>dialog.close();document.getElementById('enableNotifications').onclick=async()=>{const permission=await Notification.requestPermission();document.getElementById('ordersStatus').textContent=permission==='granted'?'Уведомления об учебных заказах включены.':'Разрешение не выдано.';if(permission==='granted')triziniiTrack('notification_opt_in')};
  setupAccessibility();
 }
});

function setupAccessibility(){
 const dialogs=[...document.querySelectorAll('.modal')];let previous=new Map(),opened=[];
 function sync(){
  const active=dialogs.filter(m=>m.classList.contains('active')),opening=[],closing=[];
  for(const m of dialogs){const is=active.includes(m),was=opened.includes(m);m.setAttribute('aria-hidden',String(!is));if(is&&!was){previous.set(m,document.activeElement);opening.push(m)}if(!is&&was)closing.push(previous.get(m))}
  opened=active;const has=active.length>0;document.querySelectorAll('header,main,footer,.back-to-top').forEach(e=>e.inert=has);dialogs.forEach(m=>m.inert=has&&!active.includes(m));document.body.style.overflow=has?'hidden':'';
  if(opening.length)requestAnimationFrame(()=>opening.at(-1).focus());else{const prev=closing.at(-1);if(prev?.isConnected)prev.focus()}
 }
 dialogs.forEach(m=>new MutationObserver(sync).observe(m,{attributes:true,attributeFilter:['class']}));sync();
 document.addEventListener('keydown',e=>{const m=opened.at(-1);if(!m)return;if(e.key==='Escape'){m.classList.remove('active');e.preventDefault()}if(e.key==='Tab'){const focusable=[...m.querySelectorAll('button,a[href],input,select,textarea,[tabindex="0"]')].filter(x=>!x.disabled&&x.getClientRects().length);const first=focusable[0],last=focusable.at(-1);if(!first){e.preventDefault();m.focus()}else if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}});
 document.querySelectorAll('.rating-stars i').forEach((s,i)=>{s.setAttribute('role','button');s.tabIndex=0;s.setAttribute('aria-label',`${i+1} из 5`);s.setAttribute('aria-hidden','false');s.addEventListener('keydown',e=>{if(['Enter',' '].includes(e.key)){e.preventDefault();s.click()}})});
 function dynamic(){const cb=document.getElementById("cartButton");if(cb)cb.setAttribute("aria-label","Открыть корзину, товаров "+document.getElementById("cartCount").textContent);document.querySelectorAll('.quantity-btn').forEach(b=>b.setAttribute('aria-label',b.classList.contains('minus')?'Уменьшить количество':'Увеличить количество'));document.querySelectorAll('.remove-item').forEach(b=>b.setAttribute('aria-label','Удалить товар из корзины'));document.querySelectorAll('.notification').forEach(n=>{n.setAttribute('role','status');n.setAttribute('aria-live','polite')});document.querySelectorAll('.size-option').forEach(b=>b.setAttribute('aria-pressed',String(b.classList.contains('selected'))));}
 new MutationObserver(dynamic).observe(document.body,{childList:true,subtree:true});dynamic();
 document.querySelectorAll('.theme-btn').forEach(b=>b.addEventListener('click',()=>document.querySelectorAll('.theme-btn').forEach(x=>x.setAttribute('aria-pressed',String(x===b)))));
 document.querySelectorAll('th').forEach(th=>th.setAttribute('scope','col'));
 document.querySelectorAll('.size-tabs button').forEach(b=>b.addEventListener('click',()=>document.querySelectorAll('.size-tabs button').forEach(x=>x.setAttribute('aria-pressed',String(x===b)))));
}



if(document.getElementById('preparedPosts'))fetch('content/posts.json').then(r=>r.json()).then(posts=>{document.getElementById('preparedPosts').innerHTML=posts.map(p=>'<article><p class=eyebrow>'+esc(p.platform)+' · '+esc(p.date)+'</p><h3>'+esc(p.title)+'</h3><p>'+esc(p.text)+'</p><a href='+esc(p.link)+'>Открыть материал</a></article>').join('')});

function renderExtraStudio(d){
 const contacts=document.getElementById('crmContacts');if(contacts)contacts.innerHTML=table(['ID','Email','Интерес','Частота','Статус','Согласие'],(d.contacts||[]).map(c=>[c.id,c.email,c.interest,c.frequency,c.status,new Date(c.consent_at*1000).toLocaleString('ru-RU')]));
 const scores=d.feedback||[],n=scores.length;const nps=n?Math.round((scores.filter(x=>x.score>=9).length-scores.filter(x=>x.score<=6).length)/n*100):null;
 const summary=document.getElementById('npsSummary');if(summary)summary.textContent=n?'Учебных ответов: '+n+'. NPS: '+nps+'.':'Оценок пока нет. После заказа нажмите «Мои заказы» → «Оценить покупку».';
 const f=document.getElementById('feedbackTable');if(f)f.innerHTML=table(['Заказ','Оценка','Дата'],scores.map(x=>[x.order_id,x.score,new Date(x.created_at*1000).toLocaleString('ru-RU')]));
 const dev=document.getElementById('deviceSummary');if(dev)dev.innerHTML=table(['Устройство','Просмотры','Добавления в корзину','Заказы'],['mobile','tablet','desktop'].map(type=>[type,...['page_view','add_to_cart','purchase'].map(name=>d.events.filter(e=>e.name===name&&e.details.device===type).length)]));
}
