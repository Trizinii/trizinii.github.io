// Local evidence log. No external counter or personal data is sent.
(()=>{const id=document.body.dataset.article||'index',key='trizinii-content-events-v1';
window.triziniiContentEvents=[];try{window.triziniiContentEvents=JSON.parse(localStorage.getItem(key)||'[]')}catch(e){}
const record=(name)=>{const event={name,article:id,variant:new URLSearchParams(location.search).get('variant')==='b'?'b':'a',time:new Date().toISOString()};window.triziniiContentEvents.push(event);try{localStorage.setItem(key,JSON.stringify(window.triziniiContentEvents.slice(-500)))}catch(e){}document.dispatchEvent(new CustomEvent('trizinii-content-event',{detail:event}));};
const seen=new Set();const read=()=>{const el=document.querySelector('[data-reading]');if(!el)return;const r=el.getBoundingClientRect(),progress=Math.min(1,Math.max(0,(innerHeight-r.top)/Math.max(1,r.height)));for(const n of [50,90])if(progress>=n/100&&!seen.has(n)){seen.add(n);record('content_read_'+n)}};
addEventListener('scroll',read,{passive:true});addEventListener('resize',read);read();
document.querySelectorAll('[data-event]').forEach(a=>a.addEventListener('click',()=>record(a.dataset.event)));
if(new URLSearchParams(location.search).get('variant')==='b')document.querySelectorAll('[data-cta-b]').forEach(a=>a.textContent=a.dataset.ctaB);
})();
